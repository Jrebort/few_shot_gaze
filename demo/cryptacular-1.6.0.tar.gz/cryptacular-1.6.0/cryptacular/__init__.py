import pkg_resources # pragma NO COVERAGE
pkg_resources.declare_namespace(__name__) # pragma NO COVERAGE
